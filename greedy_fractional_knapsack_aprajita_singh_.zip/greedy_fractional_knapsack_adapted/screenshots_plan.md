# Screenshot plan

Capture from your own running animation and save in `figures/`:
1. `frame1.png`: sorted ratios before selection.
2. `frame2.png`: item A selected.
3. `frame3.png`: A and B selected.
4. `frame4.png`: 20 kg (two-thirds) of C selected; total value 240.

Use genuine screenshots of the running program; the three supplied figures are explanatory diagrams, not substitutes for animation frames.
