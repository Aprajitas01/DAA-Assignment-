# References and AI-use disclosure guidance

## Starting references (verify access/date and format to match your course style)
1. Cormen, T. H., Leiserson, C. E., Rivest, R. L., and Stein, C. (2022). *Introduction to Algorithms* (4th ed.). MIT Press. See the chapters on greedy algorithms.
2. Kleinberg, J., and Tardos, É. (2006). *Algorithm Design*. Pearson. See the greedy algorithms material.
3. Python Software Foundation. *Python 3 Documentation*. https://docs.python.org/3/
4. Matplotlib Development Team. *Matplotlib Documentation*. https://matplotlib.org/stable/
5. Overleaf. *Learn LaTeX in 30 minutes*. https://www.overleaf.com/learn/latex/Learn_LaTeX_in_30_minutes

Consult the sources yourself and cite only sources you actually used. Add access dates if required by your teacher.

## AI-use disclosure — adapt only if accurate
“An AI assistant was used for limited brainstorming, project planning, and initial debugging guidance for the animation scaffold. I reviewed, tested, and modified the final code and wrote/revised the submitted explanations myself. All external sources used are cited in the report.”

Important: this project scaffold was generated with AI assistance. Your instructor's policy caps AI-generated content at 20%. Do not assume that including a disclosure makes an over-limit submission acceptable. Check the course rules, keep the generated material within the permitted limit, and document the actual assistance honestly. If the course requires a different disclosure format, use that format.
