# Template notes

Adapted from your uploaded UPES LaTeX template. Before submission:
- Fill in full name, SAP ID and batch; confirm the course code.
- Replace the example GitHub URL with a real link.
- Run the animation and save genuine screenshots as `figures/frame1.png` through `figures/frame4.png`.
- Rewrite/adapt explanations in your own words, verify references, and follow the 20% AI-content cap.
- Change `\showguidancetrue` to `\showguidancefalse` for the final PDF.
