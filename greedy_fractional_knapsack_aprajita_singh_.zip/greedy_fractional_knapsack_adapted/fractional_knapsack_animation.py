"""
Fractional Knapsack: step-by-step greedy animation
Requirements: Python 3.9+ and matplotlib
Run: python fractional_knapsack_animation.py
Optional custom data: edit ITEMS and CAPACITY below.
"""
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

# Sample dataset; edit these values to test your own input.
ITEMS = [
    {"name": "A", "weight": 10, "value": 60},
    {"name": "B", "weight": 20, "value": 100},
    {"name": "C", "weight": 30, "value": 120},
]
CAPACITY = 50

def fractional_knapsack(items, capacity):
    """Return sorted items and a decision record for each greedy step."""
    ordered = []
    for item in items:
        if item["weight"] <= 0 or item["value"] < 0:
            raise ValueError("Weights must be positive and values non-negative.")
        ordered.append({**item, "ratio": item["value"] / item["weight"]})
    ordered.sort(key=lambda x: x["ratio"], reverse=True)

    remaining = capacity
    total_value = 0.0
    records = []
    for item in ordered:
        if remaining <= 0:
            break
        taken = min(item["weight"], remaining)
        fraction = taken / item["weight"]
        earned = item["value"] * fraction
        remaining -= taken
        total_value += earned
        records.append({
            **item, "taken": taken, "fraction": fraction,
            "earned": earned, "remaining": remaining,
            "total_value": total_value
        })
    return ordered, records, total_value, remaining

def main():
    if CAPACITY < 0:
        raise ValueError("Capacity cannot be negative.")
    ordered, records, best_value, remaining = fractional_knapsack(ITEMS, CAPACITY)
    if not records:
        print("No items selected (capacity is zero or no items supplied).")
        return

    fig, (ax_items, ax_bag) = plt.subplots(
        2, 1, figsize=(10, 7), gridspec_kw={"height_ratios": [2.2, 1]}
    )
    fig.subplots_adjust(hspace=0.55, top=0.88, bottom=0.18)
    fig.suptitle("Fractional Knapsack — Greedy Algorithm", fontsize=16, fontweight="bold")

    names = [x["name"] for x in ordered]
    ratios = [x["ratio"] for x in ordered]
    y_positions = list(range(len(ordered)))
    bars = ax_items.barh(y_positions, ratios, color=["#2471A3"] * len(ordered), edgecolor="black")
    ax_items.set_yticks(y_positions, names)
    ax_items.invert_yaxis()
    ax_items.set_xlabel("Value / weight ratio")
    ax_items.set_title("Items sorted from highest to lowest ratio")
    ax_items.grid(axis="x", alpha=0.25)
    for bar, ratio in zip(bars, ratios):
        ax_items.text(bar.get_width() + max(ratios + [1]) * 0.02,
                      bar.get_y() + bar.get_height()/2, f"{ratio:.2f}", va="center")

    ax_bag.set_xlim(0, max(CAPACITY, 1))
    ax_bag.set_ylim(-0.7, 1.0)
    ax_bag.set_yticks([])
    ax_bag.set_xlabel("Weight placed in knapsack")
    ax_bag.set_title(f"Capacity = {CAPACITY} | Filled = 0")
    ax_bag.grid(axis="x", alpha=0.25)
    fill_segments = []
    info = fig.text(0.5, 0.035, "", ha="center", va="center", fontsize=11,
                    bbox=dict(boxstyle="round,pad=0.5", facecolor="#F4F6F7", edgecolor="#7F8C8D"))

    colors = ["#2E86C1", "#28B463", "#F39C12", "#8E44AD", "#D35400"]
    current = {"index": -1}

    def update(frame):
        # frame 0 is the introductory sorted-ratio view; subsequent frames add one choice.
        for seg in fill_segments:
            seg.remove()
        fill_segments.clear()
        if frame == 0:
            ax_bag.set_title(f"Capacity = {CAPACITY} | Filled = 0")
            info.set_text("Step 0: Sort items by value-to-weight ratio; choose the highest ratio first.")
            for bar in bars:
                bar.set_color("#2471A3")
            return list(bars) + [info]

        step = min(frame - 1, len(records) - 1)
        rec = records[step]
        for bar in bars:
            bar.set_color("#2471A3")
        # Highlight the item corresponding to this decision.
        idx = names.index(rec["name"])
        bars[idx].set_color("#F4D03F")
        left = 0
        for j, chosen in enumerate(records[:step + 1]):
            color = colors[j % len(colors)]
            seg = ax_bag.barh([0], [chosen["taken"]], left=left, height=0.55,
                              color=color, edgecolor="white")
            fill_segments.extend(seg)
            center = left + chosen["taken"] / 2
            ax_bag.text(center, 0, f'{chosen["name"]}\n{chosen["taken"]:g} kg',
                        ha="center", va="center", color="white", fontweight="bold", fontsize=9)
            left += chosen["taken"]
        ax_bag.set_title(
            f"Capacity = {CAPACITY} | Filled = {CAPACITY - rec['remaining']:g} | "
            f"Remaining = {rec['remaining']:g}"
        )
        fraction_text = f"{rec['fraction']:.1%} of item {rec['name']}"
        info.set_text(
            f"Step {step + 1}: take {rec['taken']:g} kg of {rec['name']} "
            f"({fraction_text}); value added = {rec['earned']:.2f}; "
            f"total value = {rec['total_value']:.2f}"
        )
        return list(bars) + fill_segments + [info]

    anim = FuncAnimation(fig, update, frames=len(records) + 1, interval=1800,
                         repeat=False, blit=False)
    print("Sorted items:")
    for item in ordered:
        print(f"  {item['name']}: weight={item['weight']}, value={item['value']}, ratio={item['ratio']:.2f}")
    print(f"\nMaximum value = {best_value:.2f}")
    print(f"Unused capacity = {remaining:g}")
    print("\nClose the animation window to exit.")
    plt.show()

if __name__ == "__main__":
    main()
