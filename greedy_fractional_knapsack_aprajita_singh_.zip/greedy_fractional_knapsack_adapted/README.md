# Greedy Paradigm and Fractional Knapsack

- `main.tex`: topic-specific scaffold in your uploaded UPES template style.
- `references.bib`: references for DAA.
- `fractional_knapsack_animation.py`: Matplotlib animation.
- `figures/`: three explanatory figures plus placeholders for four screenshots.

## Run
`python -m pip install -r requirements.txt`
`python fractional_knapsack_animation.py`

## Overleaf
Upload `main.tex`, `references.bib`, the Python file, requirements file, and the complete `figures` folder. Compile with pdfLaTeX and run BibTeX if needed.

## Before submission
Fill personal details, replace the URL, capture real animation screenshots, switch `\showguidancetrue` to `\showguidancefalse`, verify citations, and ensure AI-generated content remains within the course limit.
